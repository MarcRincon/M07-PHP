<html>
  <head>
    <title>PHP Test2</title>
  </head>
  <body>
 <p><?php
 $result = "";
 $number1 = (trim($_POST['num1']));
 $number2 = (trim($_POST['num2']));
 if(trim($_POST['operacio']) == "suma"){
  $result =  (int)$number1 + (int)$number2;
 } else if (trim($_POST['operacio']) == "resta"){
  $result =  (int)$number1 - (int)$number2;
 } else if (trim($_POST['operacio']) == "divisio"){
  $result =  (int)$number1 / (int)$number2;
 } else if (trim($_POST['operacio']) == "multiplicacio"){
  $result =  (int)$number1 * (int)$number2;
 }
  echo ($result) ?></p>
  </body>
</html>