<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
 <form method="post" action="rebre.php">
 <p>Num1: <input type="text" name="num1" /></p>
 <p>Acció 
   <select name="operacio" id="operacio">
    <option value="suma">Suma</option>
    <option value="resta">Resta</option>
    <option value="divisio">Divisió</option>
    <option value="multiplicacio">Multiplicació</option>
  </select>
 </p>
 <p>Num2: <input type="text" name="num2" /></p>
 <p><input type="submit" name="Enviar"/></p>
</form>
  </body>
</html>