<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php
    $A = 6;
    $B = 5;
     ?> 
     <table style="width:100%" border = "1px solid black">
  <tr>
    <td><b>Operacion</b></td>
    <td><b>Valor</b></td>
  </tr>
  <tr>
    <td>A</td>
    <td><?php echo($A) ?></td>
  </tr>
    <tr>
    <td>B</td>
    <td><?php echo($B) ?></td>
  </tr>
    <tr>
    <td>A+B</td>
    <td><?php echo($A + $B) ?></td>
  </tr>
    <tr>
    <td>A-B</td>
    <td><?php echo($A - $B) ?></td>
  </tr>
    <tr>
    <td>A*B</td>
    <td><?php echo($A * $B) ?></td>
  </tr>
    <tr>
    <td>A/B</td>
    <td><?php echo($A/$B) ?></td>
  </tr>
    <tr>
    <td>AexpB</td>
    <td><?php echo($A ** $B) ?></td>
</table> 
  </body>
</html>